<?php

namespace Ruzolcic;

/**
 * @Entity @Table(name="programskiJezici")
 **/


class ProgramskiJezici
{
    /** @id @Column(type="integer") @GeneratedValue **/
    protected $sifra;

    /**
    * @Column(type="string")
    */
    private $naziv;

    /**
    * @Column(type="string")
    */
    private $tvorac;

      /**
    * @Column(type="string")
    */
    private $programskaParadigma;

    /**
    * @Column(type="string")
    */
    private $opis;

    public function getSifra(){
      return $this->sifra;
    }
  
    public function setSifra($sifra){
      $this->sifra = $sifra;
    }
  
    public function getNaziv(){
      return $this->naziv;
    }
  
    public function setNaziv($naziv){
      $this->naziv = $naziv;
    }
  
    public function getTvorac(){
      return $this->tvorac;
    }
  
    public function setTvorac($tvorac){
      $this->tvorac = $tvorac;
    }
  
    public function getProgramskaParadigma(){
      return $this->programskaParadigma;
    }
  
    public function setProgramskaParadigma($programskaParadigma){
      $this->programskaParadigma = $programskaParadigma;
    }
  
    public function getOpis(){
      return $this->opis;
    }
  
    public function setOpis($opis){
      $this->opis = $opis;
    }

    
  public function setPodaci($podaci)
	{
		foreach($podaci as $kljuc => $vrijednost){
			$this->{$kljuc} = $vrijednost;
		}
	}

}



?>
