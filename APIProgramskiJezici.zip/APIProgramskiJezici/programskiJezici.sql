create database aruzolcic_19 default character set utf8;
use aruzolcic_19;
create table programskiJezici(
    sifra int not null primary key auto_increment,
    naziv varchar(255) not null,
    tvorac varchar(100) not null,
    programskaParadigma varchar(100) not null,
    opis text not null
);
insert into programskiJezici(naziv, tvorac, programskaParadigma, opis) 
values ("jezik",  "jezik", "jezik", "jezik" );

