<?php
require 'vendor/autoload.php';
require 'bootstrap.php';
use Ruzolcic\ProgramskiJezici;
use Ruzolcic\Projekt;
use Composer\Autoload\ClassLoader;

Flight::route('/', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20192020/aruzolcic_19/aruzolcic.rdf'); 
  $info = $foaf->dump();
  echo "<h2>Ontologija programskih jezika za P3 zadatak:</h2> <br/><br/>" . $info;
});

Flight::route('GET /search', function(){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Ruzolcic\ProgramskiJezici');
  $zapisi = $repozitorij->findAll();
  echo $doctrineBootstrap->getJson($zapisi);
});


Flight::route('GET /unesi_podatke', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20192020/aruzolcic_19/aruzolcic.rdf');
  foreach ($foaf->resources() as $resource) {

    $name = $foaf->get($resource, 'foaf:name'); 

    if($name != ''){

      $i = 0;
      $types[] = [];
      $annotations = "";

      $creator = $foaf->get($resource, 'dc:creator');
      $description = $foaf->get($resource, 'dc:description'); 
     

      foreach ($resource->properties() as $key) {
          $annotations .= $key . ': ' . $foaf->get($resource, $key) . "\n"; 
      }

      $programskiJezici = new ProgramskiJezici();
      $programskiJezici->setPodaci(Flight::request()->data);

      $programskiJezici->setNaziv($name); 
      $programskiJezici->setTvorac($creator);
      $programskiJezici->setProgramskaParadigma($description);
      $programskiJezici->setOpis($annotations);

      $doctrineBootstrap = Flight::entityManager();
      $em = $doctrineBootstrap->getEntityManager();

      $em->persist($programskiJezici);
      $em->flush();

    }
  }

  echo "U bazu je uspješno unijeta ontologija programskih jezika.";

});

Flight::route('GET /search/@name', function($name){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Ruzolcic\ProgramskiJezici');
  $zapisi = $repozitorij->createQueryBuilder('p')
                        ->where('p.naziv LIKE :naziv')
                        ->setParameter('naziv', '%'.$name.'%')
                        ->getQuery()
                        ->getResult();  
  echo $doctrineBootstrap->getJson($zapisi);

});

$cl = new ClassLoader('Ruzolcic', __DIR__, '/src');
$cl->register();
require_once 'bootstrap.php';
Flight::register('entityManager', 'DoctrineBootstrap');

Flight::start();


